﻿// lib/p2p/p2p_service.dart
//
// Abstract service + stub implementation.
// RealP2PService (real_p2p_service.dart) is the production implementation.

import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';

import '../models/message.dart';
import '../models/peer.dart';

abstract class P2PService extends ChangeNotifier {
  String get myName;
  String get myIp;
  bool get isOnline;
  bool get isInitialized;

  Map<String, Peer> get peers;
  List<ChatMessage> get messages;

  Future<void> init({String password});
  Future<void> sendMessage(String targetUid, String text);
  Future<void> broadcastMessage(String text);
  Future<void> sendFile(String targetUid, String filename, Uint8List data);
  Future<void> sendGroupMessage(List<String> memberUids, String text);
  void refreshPeers();
  void addLocalMessage(ChatMessage msg);

  // Change local display name and persist it.
  Future<void> setMyName(String name);
}

class P2PServiceStub extends P2PService {
  String _myName = 'MY_NODE';
  String _myIp = '—';
  bool _isOnline = false;
  bool _isInitialized = false;

  final Map<String, Peer> _peers = {};
  final List<ChatMessage> _messages = [];

  @override
  String get myName => _myName;
  @override
  String get myIp => _myIp;
  @override
  bool get isOnline => _isOnline;
  @override
  bool get isInitialized => _isInitialized;
  @override
  Map<String, Peer> get peers => Map.unmodifiable(_peers);
  @override
  List<ChatMessage> get messages => List.unmodifiable(_messages);

  @override
  Future<void> init({String password = 'default'}) async {
    await Future.delayed(const Duration(milliseconds: 600));

    try {
      final interfaces = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLoopback: false,
      );
      for (final iface in interfaces) {
        if (iface.addresses.isNotEmpty) {
          _myIp = iface.addresses.first.address;
          break;
        }
      }
    } catch (_) {
      _myIp = '127.0.0.1';
    }

    _isOnline = true;
    _isInitialized = true;
    notifyListeners();
  }

  @override
  Future<void> sendMessage(String targetUid, String text) async {}

  @override
  Future<void> broadcastMessage(String text) async {
    for (final uid in _peers.keys) {
      await sendMessage(uid, text);
    }
  }

  @override
  Future<void> sendFile(String targetUid, String filename, Uint8List data) async {}

  @override
  Future<void> sendGroupMessage(List<String> memberUids, String text) async {}

  @override
  void refreshPeers() => notifyListeners();

  @override
  void addLocalMessage(ChatMessage msg) {
    _messages.add(msg);
    notifyListeners();
  }

  @override
  Future<void> setMyName(String name) async {
    final trimmed = name.trim();
    if (trimmed.isEmpty) return;
    _myName = trimmed;
    notifyListeners();
  }

  @override
  void dispose() => super.dispose();
}

